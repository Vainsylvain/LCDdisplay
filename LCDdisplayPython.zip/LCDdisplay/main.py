# Bienvenue dans cette petite application codée en python pour l'impression, dans la console en format LCD, de chiffres
# saisis par l'utilisateur
# ----------------------------------------------------------------------------------------------------------------------


# ---------------------------------------Déclaration des listes de travail----------------------------------------------
# Déclaration de trois listes qui vont construire les numéros en LCD dans la console
# Chiffres            0       1        2       3      4        5       6       7       8      9
ligne_symboles_1 = [" __ ", "    ", " __ ", " __ ", "    ", " __ ", " __ ", " __ ", " __ ", " __ "]
ligne_symboles_2 = ["|  |", "   |", " __|", " __|", "|__|", "|__ ", "|__ ", "   |", "|__|", "|__|"]
ligne_symboles_3 = ["|__|", "   |", "|__ ", " __|", "   |", " __|", "|__|", "   |", "|__|", " __|"]

# Déclaration de trois listes vides remplies automatiquement par l'algorithme servant pour l'impression sur la console
ligne_1_a_imprimer = []
ligne_2_a_imprimer = []
ligne_3_a_imprimer = []


# ----------------------------------------------------------------------------------------------------------------------
# Création fonction constructeur objet "Saisie" pour tester si saisie de chiffres uniquement et pour retourner une liste
# qui les contient
class Saisie:
    def __init__(self, str_saisie_a_imprimer_en_lcd):
        self.str_saisie_a_imprimer_en_lcd = str_saisie_a_imprimer_en_lcd

    def estnumero(self):  # Test présence de chiffres uniquement dans la saisie et retourner un booléen
        try:
            int(self.str_saisie_a_imprimer_en_lcd)
            return True
        except ValueError:
            return False

    def liste(self):  # Retourner une liste contenant les caractères saisis
        return list(self.str_saisie_a_imprimer_en_lcd)


# Fonction d'impression du résultat sur la console python
def afficher_resultat_console():  # Afficher les résultats sur 3 lignes successives avec la méthode .join()
    print(" ".join(ligne_1_a_imprimer))
    print(" ".join(ligne_2_a_imprimer))
    print(" ".join(ligne_3_a_imprimer))


# ----------------------------------------------------------------------------------------------------------------------
# Demande de saisie utilisateur
saisie_utilisateur = input("Veuillez saisir un nombre pour l'afficher en LCD sur l'écran de la console : ")


# ---------------------------Algorithme d'impression des chiffres en LCD sur la console---------------------------------
if Saisie(saisie_utilisateur).estnumero():  # Test si la saisie ne comporte que des chiffres
    for chiffre_saisis in Saisie(saisie_utilisateur).liste():  # Boucle remplissage des listes vides via méthode append
        ligne_1_a_imprimer.append(str(ligne_symboles_1[int(chiffre_saisis)]))
        ligne_2_a_imprimer.append(str(ligne_symboles_2[int(chiffre_saisis)]))
        ligne_3_a_imprimer.append(str(ligne_symboles_3[int(chiffre_saisis)]))
    afficher_resultat_console()
else:  # Affichage message d'erreur si un seul élément saisi n'est pas un chiffre
    print("Vous devez saisir uniquement des chiffres pour pouvoir imprimer le nombre en LCD display.")
